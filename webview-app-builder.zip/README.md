# 🌐 WebView App Builder

A production-grade, local-first Android application built with **Kotlin**, **Java**, **Jetpack Compose**, and **AndroidX** to manage, package, and run Web Apps and offline HTML/CSS/JS projects inside an Android environment.

[![Build Android APK](https://github.com/aistudio/webview-app-builder/actions/workflows/build-apk.yml/badge.svg)](https://github.com/aistudio/webview-app-builder/actions/workflows/build-apk.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Android%207.0%2B%20(API%2024%2B)-green.svg)](https://android.com)

---

## 🚀 Key Features

### 1. 📱 Home Screen Launcher (Launcher Experience)
- **Multi-page Grid**: Swipe horizontally across multiple home screen pages with animated page indicators.
- **Customizable Grid**: Choose between 3, 4, or 5 columns.
- **App Logos & Styling**: Pick custom logos from device gallery or use vibrant automatic initials; customizable icon shapes (Rounded Square, Circle, Squircle).
- **Folder Management**: Create colored folders, group multiple web apps into folders, open folder popup grids, or move apps in and out of folders.
- **Privacy & Security**: PIN lock protection for individual apps or entire app lock; hide apps from launcher with a settings unhide manager.
- **Dynamic Wallpapers**: Choose from solid colors, vibrant modern gradients (Sunset, Ocean, Aurora, Neon), or any photo from the device gallery.
- **Real-Time Search**: Instant filtering and search across all apps and folders.

### 2. 🌍 Internal Web Browser & WebView Engine
- **Navigation Controls**: Back, Forward, Reload, Home, Page Title & SSL Security indicator.
- **Full Screen Mode**: Immersive full-screen browsing with quick-exit toggle.
- **Desktop / Mobile Toggle**: Switch between Mobile viewport and Linux/Chrome Desktop User Agent on the fly.
- **Download Manager**: Native Android `DownloadManager` integration handling file downloads with cookies and user agents.
- **File Chooser (`<input type="file">`)**: Native Android photo/document picker handling file uploads from web forms.
- **Hardware Permissions**: Graceful camera (`getUserMedia`) and microphone permissions handling in WebView.
- **Session & Cookies**: Persistent cookie and session management, plus dedicated Incognito mode for private browsing.

### 3. ⌨️ Modular In-App Custom Keyboard
- Designed specifically for interacting with Web Apps without disrupting site layout:
  - **فارسی (Persian)** complete layout with letters, nim-faseleh, and Persian digits (`۱۲۳۴۵۶۷۸۹۰`).
  - **English (QWERTY)** with shift support.
  - **Numbers & Symbols** (`?123`).
  - **Emoji Panel** (`😀 🎉 🚀 🔥 💡`).
  - Backspace, Enter/Submit, and Space bar.
- **WebView Bridge**: Uses direct cursor text manipulation and event dispatching (`input`, `change`, `keydown`) so single-page apps and reactive frameworks react immediately.

### 4. 🛠️ HTML App Builder & ZIP Project Extractor
- **In-App Code Editor**: Build client-side HTML, CSS, and JavaScript projects directly in the app.
- **Live Preview Tab**: Interactive live preview before saving.
- **ZIP Project Support**: Upload complete web applications packaged as `.zip` archives.
- **Security-First Path Traversal Protection**: Uses `ZipSecurityUtil.java` ensuring extracted archive entries cannot escape the sandboxed destination directory (mitigating "Zip Slip" vulnerabilities).

### 5. 💾 Backup & Restore
- Export all configurations, folders, and web app links into a single formatted JSON payload.
- One-tap restore to migrate apps and preferences across devices without cloud dependence.

---

## 🏛️ Architecture & Tech Stack

```
com.example/
├── data/
│   ├── dao/
│   │   ├── FolderDao.kt
│   │   └── WebAppDao.kt
│   ├── model/
│   │   ├── AppFolder.kt
│   │   ├── AppSettings.kt
│   │   └── WebAppItem.kt
│   ├── AppDatabase.kt
│   └── AppRepository.kt
├── ui/
│   ├── browser/
│   │   └── WebViewScreen.kt
│   ├── keyboard/
│   │   └── CustomInAppKeyboard.kt
│   ├── launcher/
│   │   ├── AddAppDialog.kt
│   │   ├── AppearanceDialog.kt
│   │   ├── EditAppDialog.kt
│   │   ├── FolderDialog.kt
│   │   ├── HomeScreen.kt
│   │   ├── HtmlBuilderScreen.kt
│   │   ├── PinLockDialog.kt
│   │   └── SettingsDialog.kt
│   └── theme/
├── util/
│   ├── FileUtils.kt (Kotlin)
│   └── ZipSecurityUtil.java (Java - Zip Slip security & interop)
├── viewmodel/
│   └── AppViewModel.kt
└── MainActivity.kt
```

- **Kotlin & Java Interop**: Pure Kotlin UI and ViewModel, backed by Java security utilities.
- **Jetpack Compose & Material 3**: Edge-to-edge UI, responsive adaptive grids, smooth animations.
- **Room Database**: Offline persistence of apps and folders with SQLite.
- **Coil**: Asynchronous image caching for app logos and custom wallpapers.
- **GitHub Actions**: Automated CI pipeline (`.github/workflows/build-apk.yml`) building the APK artifact on every push.

---

## 🔧 Building & Testing

### Prerequisites
- JDK 17
- Android SDK (API 24 to 35)

### Build Debug APK
```bash
gradle assembleDebug
```

The APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

### Run Unit Tests
```bash
gradle :app:testDebugUnitTest
```

---

## 📄 License
This project is open-source under the MIT License.
