package com.example.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Utility class implemented in Java to demonstrate seamless Java + Kotlin interop
 * and provide secure extraction of HTML project ZIP archives preventing "Zip Slip"
 * (Path Traversal vulnerabilities).
 */
public final class ZipSecurityUtil {

    private ZipSecurityUtil() {
        // Utility class
    }

    /**
     * Safely extracts a ZIP stream into the target directory, preventing path traversal attacks.
     *
     * @param zipInputStream Stream containing the ZIP archive
     * @param targetDirectory Directory where contents will be extracted
     * @return File pointing to index.html if found, or null
     * @throws IOException If an I/O error or security violation occurs
     */
    public static File extractSafely(InputStream zipInputStream, File targetDirectory) throws IOException {
        if (!targetDirectory.exists() && !targetDirectory.mkdirs()) {
            throw new IOException("Failed to create target directory: " + targetDirectory.getAbsolutePath());
        }

        String canonicalDestDirPath = targetDirectory.getCanonicalPath();
        File foundIndexHtml = null;

        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(zipInputStream))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];

            while ((entry = zis.getNextEntry()) != null) {
                String entryName = entry.getName();

                // Prevent directory traversal (Zip Slip)
                File newFile = new File(targetDirectory, entryName);
                String canonicalDestFilePath = newFile.getCanonicalPath();

                if (!canonicalDestFilePath.startsWith(canonicalDestDirPath + File.separator) &&
                    !canonicalDestFilePath.equals(canonicalDestDirPath)) {
                    throw new SecurityException("Zip Slip path traversal attempt detected: " + entryName);
                }

                if (entry.isDirectory()) {
                    if (!newFile.isDirectory() && !newFile.mkdirs()) {
                        throw new IOException("Failed to create directory: " + newFile);
                    }
                } else {
                    File parent = newFile.getParentFile();
                    if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
                        throw new IOException("Failed to create parent directory: " + parent);
                    }

                    try (FileOutputStream fos = new FileOutputStream(newFile);
                         BufferedOutputStream bos = new BufferedOutputStream(fos, buffer.length)) {
                        int len;
                        while ((len = zis.read(buffer)) > 0) {
                            bos.write(buffer, 0, len);
                        }
                    }

                    // Check for index.html
                    if (newFile.getName().equalsIgnoreCase("index.html")) {
                        if (foundIndexHtml == null || newFile.getParent().equals(canonicalDestDirPath)) {
                            foundIndexHtml = newFile;
                        }
                    }
                }
                zis.closeEntry();
            }
        }

        return foundIndexHtml;
    }

    /**
     * Compresses a source directory into a ZIP output stream (used for Backup export).
     */
    public static void zipDirectory(File sourceDir, File zipFile) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(zipFile);
             ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(fos))) {
            zipSubFile(sourceDir, sourceDir, zos);
        }
    }

    private static void zipSubFile(File rootDir, File sourceFile, ZipOutputStream zos) throws IOException {
        if (sourceFile.isDirectory()) {
            File[] files = sourceFile.listFiles();
            if (files != null) {
                for (File file : files) {
                    zipSubFile(rootDir, file, zos);
                }
            }
        } else {
            String relativePath = rootDir.toURI().relativize(sourceFile.toURI()).getPath();
            ZipEntry entry = new ZipEntry(relativePath);
            zos.putNextEntry(entry);
            try (FileInputStream fis = new FileInputStream(sourceFile);
                 BufferedInputStream bis = new BufferedInputStream(fis, 8192)) {
                byte[] buffer = new byte[8192];
                int len;
                while ((len = bis.read(buffer)) > 0) {
                    zos.write(buffer, 0, len);
                }
            }
            zos.closeEntry();
        }
    }
}
