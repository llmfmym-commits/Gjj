package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.WebAppItem
import com.example.ui.browser.WebViewScreen
import com.example.ui.launcher.HomeScreen
import com.example.ui.launcher.HtmlBuilderScreen
import com.example.ui.launcher.PinLockDialog
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AppViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val appViewModel: AppViewModel = viewModel()
            val settings by appViewModel.settings.collectAsState()

            val isDarkTheme = when (settings.themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                MainAppNavHost(appViewModel)
            }
        }
    }
}

enum class ScreenState {
    HOME,
    BROWSER,
    HTML_BUILDER
}

@Composable
fun MainAppNavHost(viewModel: AppViewModel) {
    val settings by viewModel.settings.collectAsState()
    var currentScreen by remember { mutableStateOf(ScreenState.HOME) }
    var activeWebApp by remember { mutableStateOf<WebAppItem?>(null) }

    // Master PIN lock gate on startup if enabled
    var isMasterUnlocked by remember { mutableStateOf(!settings.appLockEnabled) }

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when (currentScreen) {
                ScreenState.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onOpenApp = { app ->
                            activeWebApp = app
                            currentScreen = ScreenState.BROWSER
                        },
                        onOpenHtmlBuilder = {
                            currentScreen = ScreenState.HTML_BUILDER
                        },
                        onPreviewApp = { previewApp ->
                            activeWebApp = previewApp
                            currentScreen = ScreenState.BROWSER
                        }
                    )
                }

                ScreenState.BROWSER -> {
                    activeWebApp?.let { appItem ->
                        WebViewScreen(
                            appItem = appItem,
                            onCloseBrowser = {
                                currentScreen = ScreenState.HOME
                                activeWebApp = null
                            }
                        )
                    } ?: run {
                        currentScreen = ScreenState.HOME
                    }
                }

                ScreenState.HTML_BUILDER -> {
                    HtmlBuilderScreen(
                        onBack = { currentScreen = ScreenState.HOME },
                        onSaveApp = { name, targetUrl, iconPath ->
                            viewModel.addWebApp(
                                name = name,
                                type = "HTML",
                                targetUrl = targetUrl,
                                iconPath = iconPath
                            )
                        }
                    )
                }
            }

            // Master App Lock Dialog
            if (settings.appLockEnabled && !isMasterUnlocked && settings.masterPin.isNotEmpty()) {
                PinLockDialog(
                    correctPin = settings.masterPin,
                    title = "ورود به WebView App Builder",
                    onUnlocked = { isMasterUnlocked = true },
                    onDismiss = { /* Keep locked */ }
                )
            }
        }
    }
}
