package com.example.ui.launcher

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AppFolder
import com.example.data.model.AppSettings
import com.example.data.model.WebAppItem
import com.example.viewmodel.AppViewModel
import java.io.File

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: AppViewModel,
    onOpenApp: (WebAppItem) -> Unit,
    onOpenHtmlBuilder: () -> Unit,
    onPreviewApp: (WebAppItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allApps by viewModel.allApps.collectAsState()
    val allFolders by viewModel.allFolders.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    // Dialog & sheet controllers
    var showAddAppDialog by remember { mutableStateOf(false) }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var showAppearanceDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    var selectedAppForEdit by remember { mutableStateOf<WebAppItem?>(null) }
    var selectedAppForLock by remember { mutableStateOf<WebAppItem?>(null) }
    var selectedFolder by remember { mutableStateOf<AppFolder?>(null) }
    var selectedAppForMenu by remember { mutableStateOf<WebAppItem?>(null) }

    // Filtered visible apps (not hidden, unless searching)
    val visibleApps = remember(allApps, searchQuery) {
        if (searchQuery.isBlank()) {
            allApps.filter { !it.isHidden }
        } else {
            allApps.filter { it.name.contains(searchQuery, ignoreCase = true) }
        }
    }

    val visibleFolders = remember(allFolders, searchQuery) {
        if (searchQuery.isBlank()) {
            allFolders
        } else {
            allFolders.filter { it.name.contains(searchQuery, ignoreCase = true) }
        }
    }

    // Determine total pages count
    val maxAppPage = visibleApps.maxOfOrNull { it.pageIndex } ?: 0
    val maxFolderPage = visibleFolders.maxOfOrNull { it.pageIndex } ?: 0
    val pageCount = maxOf(1, maxOf(maxAppPage, maxFolderPage) + 1)
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { pageCount })

    // Icon Shape calculation
    val appIconShape: Shape = remember(settings.iconShape) {
        when (settings.iconShape) {
            "CIRCLE" -> CircleShape
            "SQUIRCLE" -> RoundedCornerShape(22.dp)
            else -> RoundedCornerShape(16.dp)
        }
    }

    // Dynamic Wallpaper background
    val backgroundModifier = Modifier.fillMaxSize().then(
        when (settings.wallpaperType) {
            "COLOR" -> {
                try {
                    Modifier.background(Color(android.graphics.Color.parseColor(settings.wallpaperValue)))
                } catch (e: Exception) {
                    Modifier.background(Color(0xFF0F172A))
                }
            }
            "GRADIENT" -> {
                when (settings.wallpaperValue) {
                    "GRADIENT_SUNSET" -> Modifier.background(Brush.verticalGradient(listOf(Color(0xFFF97316), Color(0xFF9333EA))))
                    "GRADIENT_OCEAN" -> Modifier.background(Brush.verticalGradient(listOf(Color(0xFF0284C7), Color(0xFF0F172A))))
                    "GRADIENT_AURORA" -> Modifier.background(Brush.verticalGradient(listOf(Color(0xFF10B981), Color(0xFF065F46))))
                    "GRADIENT_NEON" -> Modifier.background(Brush.verticalGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))))
                    else -> Modifier.background(Brush.verticalGradient(listOf(Color(0xFF1E1B4B), Color(0xFF020617))))
                }
            }
            "IMAGE" -> {
                if (settings.wallpaperValue.isNotBlank() && File(settings.wallpaperValue).exists()) {
                    Modifier // Will render AsyncImage underneath
                } else {
                    Modifier.background(Brush.verticalGradient(listOf(Color(0xFF0F172A), Color(0xFF1E293B))))
                }
            }
            else -> Modifier.background(Brush.verticalGradient(listOf(Color(0xFF0B132B), Color(0xFF1C2541), Color(0xFF0F172A))))
        }
    )

    Box(modifier = modifier.then(backgroundModifier)) {
        // Wallpaper Image if set
        if (settings.wallpaperType == "IMAGE" && settings.wallpaperValue.isNotBlank()) {
            AsyncImage(
                model = settings.wallpaperValue,
                contentDescription = "Wallpaper",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Dark scrim overlay for readability
            Box(modifier = Modifier.fillMaxSize().background(Color(0x99000000)))
        }

        Column(modifier = Modifier.fillMaxSize()) {
            // Header Top Bar: Search and Quick Action Buttons
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0x661E293B),
                shadowElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Search Field
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setSearchQuery(it) },
                            placeholder = { Text("جستجوی برنامه‌ها...", color = Color(0xFF94A3B8), fontSize = 13.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF94A3B8), modifier = Modifier.size(18.dp))
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("search_bar"),
                            shape = RoundedCornerShape(24.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0x881E293B),
                                unfocusedContainerColor = Color(0x551E293B),
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF475569),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        // Add App Button
                        IconButton(
                            onClick = { showAddAppDialog = true },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF3B82F6))
                                .testTag("add_app_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add App", tint = Color.White)
                        }

                        // Add Folder Button
                        IconButton(
                            onClick = { showNewFolderDialog = true },
                            modifier = Modifier.size(40.dp).testTag("add_folder_button")
                        ) {
                            Icon(Icons.Default.CreateNewFolder, contentDescription = "New Folder", tint = Color(0xFF38BDF8))
                        }

                        // HTML Builder Button
                        IconButton(
                            onClick = onOpenHtmlBuilder,
                            modifier = Modifier.size(40.dp).testTag("html_builder_button")
                        ) {
                            Icon(Icons.Default.Code, contentDescription = "HTML Builder", tint = Color(0xFF10B981))
                        }

                        // Appearance Palette
                        IconButton(
                            onClick = { showAppearanceDialog = true },
                            modifier = Modifier.size(40.dp).testTag("appearance_button")
                        ) {
                            Icon(Icons.Default.Palette, contentDescription = "Appearance", tint = Color(0xFFF59E0B))
                        }

                        // Settings
                        IconButton(
                            onClick = { showSettingsDialog = true },
                            modifier = Modifier.size(40.dp).testTag("settings_button")
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color(0xFF94A3B8))
                        }
                    }
                }
            }

            // Main Content: Multi-Page Horizontal Pager
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) { page ->
                val appsOnPage = visibleApps.filter {
                    if (searchQuery.isNotBlank()) true else (it.pageIndex == page && it.folderId == null)
                }
                val foldersOnPage = visibleFolders.filter {
                    if (searchQuery.isNotBlank()) true else it.pageIndex == page
                }

                if (appsOnPage.isEmpty() && foldersOnPage.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "صفحه خالی است",
                                color = Color(0xFF94A3B8),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(onClick = { showAddAppDialog = true }) {
                                Text("+ افزودن برنامه به این صفحه")
                            }
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(settings.columnCount),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("apps_grid"),
                        contentPadding = PaddingValues(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // First render Folders
                        items(foldersOnPage, key = { "folder_${it.id}" }) { folder ->
                            val appsInFolder = allApps.filter { it.folderId == folder.id }
                            FolderGridItem(
                                folder = folder,
                                appsCount = appsInFolder.size,
                                shape = appIconShape,
                                onClick = { selectedFolder = folder },
                                onLongClick = { selectedFolder = folder }
                            )
                        }

                        // Then render standalone Apps
                        items(appsOnPage, key = { "app_${it.id}" }) { app ->
                            AppGridItem(
                                app = app,
                                shape = appIconShape,
                                onClick = {
                                    if (app.isLocked) {
                                        selectedAppForLock = app
                                    } else {
                                        viewModel.markAppUsed(app.id)
                                        onOpenApp(app)
                                    }
                                },
                                onLongClick = {
                                    selectedAppForMenu = app
                                }
                            )
                        }
                    }
                }
            }

            // Bottom Page Indicator Dots
            if (pageCount > 1 && searchQuery.isBlank()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 0 until pageCount) {
                        val isSelected = pagerState.currentPage == i
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 4.dp)
                                .size(if (isSelected) 9.dp else 6.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) Color(0xFF38BDF8) else Color(0x6694A3B8))
                        )
                    }
                }
            }
        }
    }

    // Context Menu Bottom Sheet for App
    if (selectedAppForMenu != null) {
        val app = selectedAppForMenu!!
        ModalBottomSheet(
            onDismissRequest = { selectedAppForMenu = null },
            sheetState = rememberModalBottomSheetState(),
            containerColor = Color(0xFF1E293B)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = app.name,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )

                DropdownMenuItem(
                    text = { Text("اجرا (Open)") },
                    onClick = {
                        val target = app
                        selectedAppForMenu = null
                        if (target.isLocked) {
                            selectedAppForLock = target
                        } else {
                            viewModel.markAppUsed(target.id)
                            onOpenApp(target)
                        }
                    },
                    leadingIcon = { Icon(Icons.Default.Code, contentDescription = null, tint = Color(0xFF38BDF8)) }
                )

                DropdownMenuItem(
                    text = { Text("ویرایش و تنظیمات (Edit & Settings)") },
                    onClick = {
                        val target = app
                        selectedAppForMenu = null
                        selectedAppForEdit = target
                    },
                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White) }
                )

                DropdownMenuItem(
                    text = { Text(if (app.isLocked) "حذف قفل (Unlock)" else "قفل با رمز (Lock)") },
                    onClick = {
                        val updated = app.copy(isLocked = !app.isLocked)
                        viewModel.updateApp(updated)
                        selectedAppForMenu = null
                    },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFF59E0B)) }
                )

                DropdownMenuItem(
                    text = { Text("مخفی کردن از صفحه اصلی") },
                    onClick = {
                        val updated = app.copy(isHidden = true)
                        viewModel.updateApp(updated)
                        selectedAppForMenu = null
                        Toast.makeText(context, "برنامه مخفی شد (قابل بازگردانی از تنظیمات)", Toast.LENGTH_SHORT).show()
                    },
                    leadingIcon = { Icon(Icons.Default.VisibilityOff, contentDescription = null, tint = Color.Gray) }
                )

                DropdownMenuItem(
                    text = { Text("انتقال به صفحه بعدی") },
                    onClick = {
                        viewModel.moveAppToPage(app.id, app.pageIndex + 1)
                        selectedAppForMenu = null
                    },
                    leadingIcon = { Icon(Icons.Default.DriveFileMove, contentDescription = null, tint = Color(0xFF38BDF8)) }
                )

                DropdownMenuItem(
                    text = { Text("حذف برنامه (Delete)", color = Color(0xFFEF4444)) },
                    onClick = {
                        viewModel.deleteApp(app)
                        selectedAppForMenu = null
                    },
                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFEF4444)) }
                )
            }
        }
    }

    // Add App Dialog
    if (showAddAppDialog) {
        AddAppDialog(
            onDismiss = { showAddAppDialog = false },
            onCreateApp = { name, type, targetUrl, iconPath, iconPreset ->
                viewModel.addWebApp(
                    name = name,
                    type = type,
                    targetUrl = targetUrl,
                    iconPath = iconPath,
                    iconPreset = iconPreset,
                    targetPage = pagerState.currentPage
                )
            },
            onPreviewApp = onPreviewApp
        )
    }

    // New Folder Dialog
    if (showNewFolderDialog) {
        var newFolderName by remember { mutableStateOf("") }
        var folderColorHex by remember { mutableStateOf("#3B82F6") }

        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text("ایجاد پوشه جدید", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newFolderName,
                        onValueChange = { newFolderName = it },
                        label = { Text("نام پوشه") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newFolderName.isNotBlank()) {
                            viewModel.createFolder(newFolderName.trim(), folderColorHex, pagerState.currentPage)
                            showNewFolderDialog = false
                        }
                    }
                ) {
                    Text("ایجاد پوشه")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Edit App Dialog
    if (selectedAppForEdit != null) {
        EditAppDialog(
            appItem = selectedAppForEdit!!,
            folders = allFolders,
            totalPages = pageCount,
            onDismiss = { selectedAppForEdit = null },
            onSave = { updated -> viewModel.updateApp(updated) },
            onDelete = { app -> viewModel.deleteApp(app) }
        )
    }

    // Folder Dialog
    if (selectedFolder != null) {
        val folder = selectedFolder!!
        val appsInFolder = allApps.filter { it.folderId == folder.id }
        FolderDialog(
            folder = folder,
            appsInFolder = appsInFolder,
            onDismiss = { selectedFolder = null },
            onOpenApp = { app ->
                viewModel.markAppUsed(app.id)
                onOpenApp(app)
            },
            onRemoveFromFolder = { app ->
                viewModel.moveAppToFolder(app.id, null)
            },
            onEditFolder = { updated ->
                viewModel.updateFolder(updated)
            },
            onDeleteFolder = { f ->
                viewModel.deleteFolder(f)
            }
        )
    }

    // Appearance Dialog
    if (showAppearanceDialog) {
        AppearanceDialog(
            currentSettings = settings,
            onDismiss = { showAppearanceDialog = false },
            onSaveSettings = { newSettings -> viewModel.updateSettings(newSettings) }
        )
    }

    // Settings Dialog
    if (showSettingsDialog) {
        val hiddenApps = allApps.filter { it.isHidden }
        SettingsDialog(
            currentSettings = settings,
            hiddenApps = hiddenApps,
            onDismiss = { showSettingsDialog = false },
            onSaveSettings = { newSettings -> viewModel.updateSettings(newSettings) },
            onUnhideApp = { app -> viewModel.updateApp(app.copy(isHidden = false)) },
            onExportBackup = { viewModel.exportBackupJson() },
            onRestoreBackup = { json -> viewModel.restoreBackupJson(json) }
        )
    }

    // Pin Lock Dialog for protected app
    if (selectedAppForLock != null) {
        val lockedApp = selectedAppForLock!!
        PinLockDialog(
            correctPin = if (lockedApp.pinCode.isNullOrEmpty()) settings.masterPin else lockedApp.pinCode!!,
            title = "ورود به ${lockedApp.name}",
            onUnlocked = {
                val appToOpen = selectedAppForLock!!
                selectedAppForLock = null
                viewModel.markAppUsed(appToOpen.id)
                onOpenApp(appToOpen)
            },
            onDismiss = { selectedAppForLock = null }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppGridItem(
    app: WebAppItem,
    shape: Shape,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(4.dp)
            .testTag("app_item_${app.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(shape)
                .background(Color(android.graphics.Color.parseColor(app.iconPreset ?: "#3B82F6"))),
            contentAlignment = Alignment.Center
        ) {
            if (app.iconPath != null) {
                AsyncImage(
                    model = app.iconPath,
                    contentDescription = app.name,
                    modifier = Modifier.size(60.dp),
                    contentScale = ContentScale.Crop
                )
            } else {
                Text(
                    text = app.name.take(1).uppercase(),
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Locked badge
            if (app.isLocked) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(2.dp)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF59E0B)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = Color.Black,
                        modifier = Modifier.size(11.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = app.name,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FolderGridItem(
    folder: AppFolder,
    appsCount: Int,
    shape: Shape,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(4.dp)
            .testTag("folder_item_${folder.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(shape)
                .background(Color(0x333B82F6))
                .border(1.5.dp, Color(0xFF38BDF8), shape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Folder,
                contentDescription = folder.name,
                tint = Color(0xFF38BDF8),
                modifier = Modifier.size(34.dp)
            )

            // App count badge
            if (appsCount > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF3B82F6)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$appsCount",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = folder.name,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
