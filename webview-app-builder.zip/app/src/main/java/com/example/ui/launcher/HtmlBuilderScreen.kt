package com.example.ui.launcher

import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.util.FileUtils
import java.util.UUID

@Composable
fun HtmlBuilderScreen(
    onBack: () -> Unit,
    onSaveApp: (name: String, targetUrl: String, iconPath: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var appName by remember { mutableStateOf("My HTML App") }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: HTML, 1: CSS, 2: JS, 3: Preview
    var iconPath by remember { mutableStateOf<String?>(null) }

    var htmlCode by remember {
        mutableStateOf(
            """<div class="card">
  <h2>🚀 Interactive App</h2>
  <p>Type something below:</p>
  <input id="txt" placeholder="Enter message..." />
  <button onclick="greet()">Display</button>
  <div id="output"></div>
</div>"""
        )
    }

    var cssCode by remember {
        mutableStateOf(
            """body {
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  background: #0f172a;
  color: #f8fafc;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  margin: 0;
}
.card {
  background: #1e293b;
  padding: 24px;
  border-radius: 16px;
  box-shadow: 0 10px 25px rgba(0,0,0,0.5);
  text-align: center;
  width: 85%;
  max-width: 320px;
}
input {
  width: 90%;
  padding: 10px;
  border-radius: 8px;
  border: 1px solid #475569;
  background: #0f172a;
  color: white;
  margin-bottom: 12px;
}
button {
  background: #3b82f6;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 8px;
  font-weight: bold;
  cursor: pointer;
}
#output {
  margin-top: 16px;
  font-weight: bold;
  color: #38bdf8;
}"""
        )
    }

    var jsCode by remember {
        mutableStateOf(
            """function greet() {
  const val = document.getElementById('txt').value;
  document.getElementById('output').innerText = 'Output: ' + val;
}"""
        )
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val savedPath = FileUtils.saveIconFromUri(context, uri)
            iconPath = savedPath
        }
    }

    val fullCombinedHtml = remember(htmlCode, cssCode, jsCode) {
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
$cssCode
  </style>
</head>
<body>
$htmlCode
  <script>
$jsCode
  </script>
</body>
</html>"""
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
    ) {
        // Top Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF1E293B),
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                // Logo selector mini
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF3B82F6))
                        .clickable {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (iconPath != null) {
                        AsyncImage(
                            model = iconPath,
                            contentDescription = "Logo",
                            modifier = Modifier.size(36.dp),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Add logo", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedTextField(
                    value = appName,
                    onValueChange = { appName = it },
                    singleLine = true,
                    placeholder = { Text("نام برنامه...") },
                    modifier = Modifier.weight(1f).height(50.dp),
                    textStyle = TextStyle(fontSize = 14.sp, color = Color.White)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = {
                        if (appName.isBlank()) {
                            Toast.makeText(context, "لطفاً نام برنامه را وارد کنید", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val appId = UUID.randomUUID().toString()
                        val savedPath = FileUtils.saveHtmlProject(
                            context = context,
                            appId = appId,
                            htmlContent = htmlCode,
                            cssContent = cssCode,
                            jsContent = jsCode
                        )
                        onSaveApp(appName.trim(), savedPath, iconPath)
                        Toast.makeText(context, "برنامه HTML ذخیره شد و به صفحه اصلی افزوده گشت", Toast.LENGTH_LONG).show()
                        onBack()
                    }
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ذخیره")
                }
            }
        }

        // Tabs
        val tabs = listOf("HTML", "CSS", "JavaScript", "پیش‌نمایش (Preview)")
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF1E293B),
            contentColor = Color(0xFF38BDF8)
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    OutlinedTextField(
                        value = htmlCode,
                        onValueChange = { htmlCode = it },
                        modifier = Modifier.fillMaxSize(),
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = Color(0xFFE2E8F0)
                        ),
                        placeholder = { Text("<!-- Write HTML here -->") }
                    )
                }
                1 -> {
                    OutlinedTextField(
                        value = cssCode,
                        onValueChange = { cssCode = it },
                        modifier = Modifier.fillMaxSize(),
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = Color(0xFFE2E8F0)
                        ),
                        placeholder = { Text("/* Write CSS here */") }
                    )
                }
                2 -> {
                    OutlinedTextField(
                        value = jsCode,
                        onValueChange = { jsCode = it },
                        modifier = Modifier.fillMaxSize(),
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = Color(0xFFE2E8F0)
                        ),
                        placeholder = { Text("// Write JavaScript here") }
                    )
                }
                3 -> {
                    AndroidView(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp)),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                loadDataWithBaseURL(null, fullCombinedHtml, "text/html", "UTF-8", null)
                            }
                        },
                        update = { webView ->
                            webView.loadDataWithBaseURL(null, fullCombinedHtml, "text/html", "UTF-8", null)
                        }
                    )
                }
            }
        }
    }
}
