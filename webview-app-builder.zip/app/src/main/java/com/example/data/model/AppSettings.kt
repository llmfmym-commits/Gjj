package com.example.data.model

data class AppSettings(
    val wallpaperType: String = "DEFAULT", // "DEFAULT", "COLOR", "GRADIENT", "IMAGE"
    val wallpaperValue: String = "", // Color hex, gradient key, or image file path
    val themeMode: String = "SYSTEM", // "SYSTEM", "LIGHT", "DARK"
    val columnCount: Int = 4, // 3, 4, 5
    val iconSize: String = "MEDIUM", // "SMALL", "MEDIUM", "LARGE"
    val iconShape: String = "ROUNDED_SQUARE", // "ROUNDED_SQUARE", "CIRCLE", "SQUIRCLE"
    val appLockEnabled: Boolean = false,
    val masterPin: String = "",
    val sortMode: String = "MANUAL" // "MANUAL", "NAME", "DATE_CREATED", "LAST_USED"
)
