package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.WebAppItem
import kotlinx.coroutines.flow.Flow

@Dao
interface WebAppDao {
    @Query("SELECT * FROM web_apps ORDER BY pageIndex ASC, orderIndex ASC")
    fun getAllApps(): Flow<List<WebAppItem>>

    @Query("SELECT * FROM web_apps WHERE folderId = :folderId ORDER BY orderIndex ASC")
    fun getAppsInFolder(folderId: Long): Flow<List<WebAppItem>>

    @Query("SELECT * FROM web_apps WHERE id = :id LIMIT 1")
    suspend fun getAppById(id: Long): WebAppItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApp(app: WebAppItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApps(apps: List<WebAppItem>)

    @Update
    suspend fun updateApp(app: WebAppItem)

    @Delete
    suspend fun deleteApp(app: WebAppItem)

    @Query("DELETE FROM web_apps WHERE id = :id")
    suspend fun deleteAppById(id: Long)

    @Query("UPDATE web_apps SET lastUsedAt = :timestamp WHERE id = :id")
    suspend fun updateLastUsed(id: Long, timestamp: Long)

    @Query("UPDATE web_apps SET pageIndex = :pageIndex, orderIndex = :orderIndex, folderId = :folderId WHERE id = :id")
    suspend fun updatePosition(id: Long, pageIndex: Int, orderIndex: Int, folderId: Long?)

    @Query("DELETE FROM web_apps")
    suspend fun clearAll()
}
