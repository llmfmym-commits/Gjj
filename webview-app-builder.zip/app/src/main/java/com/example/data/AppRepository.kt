package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AppFolder
import com.example.data.model.AppSettings
import com.example.data.model.WebAppItem
import com.example.util.FileUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class AppRepository(
    private val context: Context,
    private val database: AppDatabase
) {
    private val webAppDao = database.webAppDao()
    private val folderDao = database.folderDao()
    private val prefs: SharedPreferences =
        context.getSharedPreferences("app_settings_prefs", Context.MODE_PRIVATE)

    val allApps: Flow<List<WebAppItem>> = webAppDao.getAllApps()
    val allFolders: Flow<List<AppFolder>> = folderDao.getAllFolders()

    private val _settingsFlow = MutableStateFlow(loadSettings())
    val settingsFlow = _settingsFlow.asStateFlow()

    private fun loadSettings(): AppSettings {
        return AppSettings(
            wallpaperType = prefs.getString("wallpaper_type", "DEFAULT") ?: "DEFAULT",
            wallpaperValue = prefs.getString("wallpaper_value", "") ?: "",
            themeMode = prefs.getString("theme_mode", "SYSTEM") ?: "SYSTEM",
            columnCount = prefs.getInt("column_count", 4),
            iconSize = prefs.getString("icon_size", "MEDIUM") ?: "MEDIUM",
            iconShape = prefs.getString("icon_shape", "ROUNDED_SQUARE") ?: "ROUNDED_SQUARE",
            appLockEnabled = prefs.getBoolean("app_lock_enabled", false),
            masterPin = prefs.getString("master_pin", "") ?: "",
            sortMode = prefs.getString("sort_mode", "MANUAL") ?: "MANUAL"
        )
    }

    fun updateSettings(newSettings: AppSettings) {
        prefs.edit().apply {
            putString("wallpaper_type", newSettings.wallpaperType)
            putString("wallpaper_value", newSettings.wallpaperValue)
            putString("theme_mode", newSettings.themeMode)
            putInt("column_count", newSettings.columnCount)
            putString("icon_size", newSettings.iconSize)
            putString("icon_shape", newSettings.iconShape)
            putBoolean("app_lock_enabled", newSettings.appLockEnabled)
            putString("master_pin", newSettings.masterPin)
            putString("sort_mode", newSettings.sortMode)
            apply()
        }
        _settingsFlow.value = newSettings
    }

    suspend fun getAppById(id: Long): WebAppItem? = webAppDao.getAppById(id)

    suspend fun insertApp(app: WebAppItem): Long = webAppDao.insertApp(app)

    suspend fun updateApp(app: WebAppItem) = webAppDao.updateApp(app)

    suspend fun deleteApp(app: WebAppItem) {
        webAppDao.deleteApp(app)
        if (app.type != "WEB_URL") {
            FileUtils.deleteAppDirectory(context, app.id.toString())
        }
    }

    suspend fun updateLastUsed(appId: Long) {
        webAppDao.updateLastUsed(appId, System.currentTimeMillis())
    }

    suspend fun updateAppPosition(id: Long, pageIndex: Int, orderIndex: Int, folderId: Long?) {
        webAppDao.updatePosition(id, pageIndex, orderIndex, folderId)
    }

    suspend fun insertFolder(folder: AppFolder): Long = folderDao.insertFolder(folder)

    suspend fun updateFolder(folder: AppFolder) = folderDao.updateFolder(folder)

    suspend fun deleteFolder(folder: AppFolder) {
        folderDao.deleteFolder(folder)
    }

    suspend fun updateFolderPosition(id: Long, pageIndex: Int, orderIndex: Int) {
        folderDao.updatePosition(id, pageIndex, orderIndex)
    }

    /**
     * Seeds initial popular Web Apps if the database is brand new.
     */
    suspend fun seedDefaultsIfEmpty() {
        val seeded = prefs.getBoolean("has_seeded_defaults_v1", false)
        if (!seeded) {
            // Create initial interactive HTML Demo app
            val htmlAppPath = FileUtils.saveHtmlProject(
                context = context,
                appId = "demo_calc",
                htmlContent = """
                    <div style="font-family:sans-serif; text-align:center; padding:20px; color:#f1f5f9;">
                        <h2>📱 Offline HTML5 App</h2>
                        <p>This is a fully local client-side HTML app running directly inside WebView!</p>
                        <input id="num1" type="number" placeholder="Number 1" style="padding:10px; border-radius:8px; border:1px solid #475569; background:#1e293b; color:white; width:120px; margin:5px;">
                        <input id="num2" type="number" placeholder="Number 2" style="padding:10px; border-radius:8px; border:1px solid #475569; background:#1e293b; color:white; width:120px; margin:5px;">
                        <br>
                        <button onclick="calculate()" style="padding:10px 24px; margin-top:12px; background:#3b82f6; color:white; border:none; border-radius:8px; font-weight:bold; cursor:pointer;">Add Numbers</button>
                        <h3 id="res" style="color:#38bdf8; margin-top:15px;">Result: -</h3>
                    </div>
                """.trimIndent(),
                cssContent = "body { background: #0f172a; margin: 0; display:flex; justify-content:center; align-items:center; min-height:100vh; }",
                jsContent = "function calculate() { const n1 = parseFloat(document.getElementById('num1').value)||0; const n2 = parseFloat(document.getElementById('num2').value)||0; document.getElementById('res').innerText = 'Result: ' + (n1 + n2); }"
            )

            val defaultApps = listOf(
                WebAppItem(
                    name = "YouTube",
                    type = "WEB_URL",
                    targetUrl = "https://www.youtube.com",
                    iconPreset = "#EF4444",
                    pageIndex = 0,
                    orderIndex = 0
                ),
                WebAppItem(
                    name = "ChatGPT",
                    type = "WEB_URL",
                    targetUrl = "https://chatgpt.com",
                    iconPreset = "#10A37F",
                    pageIndex = 0,
                    orderIndex = 1
                ),
                WebAppItem(
                    name = "Google",
                    type = "WEB_URL",
                    targetUrl = "https://www.google.com",
                    iconPreset = "#4285F4",
                    pageIndex = 0,
                    orderIndex = 2
                ),
                WebAppItem(
                    name = "HTML Demo",
                    type = "HTML",
                    targetUrl = htmlAppPath,
                    iconPreset = "#8B5CF6",
                    pageIndex = 0,
                    orderIndex = 3
                )
            )

            for (app in defaultApps) {
                webAppDao.insertApp(app)
            }
            prefs.edit().putBoolean("has_seeded_defaults_v1", true).apply()
        }
    }

    /**
     * Exports full configuration and apps as a JSON string for Backup.
     */
    suspend fun exportBackupJson(apps: List<WebAppItem>, folders: List<AppFolder>): String {
        val root = JSONObject()
        val settings = _settingsFlow.value

        val settingsJson = JSONObject().apply {
            put("wallpaperType", settings.wallpaperType)
            put("wallpaperValue", settings.wallpaperValue)
            put("themeMode", settings.themeMode)
            put("columnCount", settings.columnCount)
            put("iconSize", settings.iconSize)
            put("iconShape", settings.iconShape)
            put("appLockEnabled", settings.appLockEnabled)
            put("masterPin", settings.masterPin)
            put("sortMode", settings.sortMode)
        }
        root.put("settings", settingsJson)

        val foldersJson = JSONArray()
        for (f in folders) {
            val fObj = JSONObject().apply {
                put("id", f.id)
                put("name", f.name)
                put("icon", f.icon)
                put("colorHex", f.colorHex)
                put("pageIndex", f.pageIndex)
                put("orderIndex", f.orderIndex)
            }
            foldersJson.put(fObj)
        }
        root.put("folders", foldersJson)

        val appsJson = JSONArray()
        for (a in apps) {
            val aObj = JSONObject().apply {
                put("name", a.name)
                put("type", a.type)
                put("targetUrl", a.targetUrl)
                put("iconPreset", a.iconPreset ?: "")
                put("pageIndex", a.pageIndex)
                put("orderIndex", a.orderIndex)
                put("folderId", a.folderId ?: -1L)
                put("isLocked", a.isLocked)
                put("javascriptEnabled", a.javascriptEnabled)
                put("desktopMode", a.desktopMode)
            }
            appsJson.put(aObj)
        }
        root.put("apps", appsJson)

        return root.toString(2)
    }

    /**
     * Restores backup from a JSON string.
     */
    suspend fun restoreBackupJson(jsonString: String): Boolean {
        return try {
            val root = JSONObject(jsonString)

            if (root.has("settings")) {
                val s = root.getJSONObject("settings")
                val restoredSettings = AppSettings(
                    wallpaperType = s.optString("wallpaperType", "DEFAULT"),
                    wallpaperValue = s.optString("wallpaperValue", ""),
                    themeMode = s.optString("themeMode", "SYSTEM"),
                    columnCount = s.optInt("columnCount", 4),
                    iconSize = s.optString("iconSize", "MEDIUM"),
                    iconShape = s.optString("iconShape", "ROUNDED_SQUARE"),
                    appLockEnabled = s.optBoolean("appLockEnabled", false),
                    masterPin = s.optString("masterPin", ""),
                    sortMode = s.optString("sortMode", "MANUAL")
                )
                updateSettings(restoredSettings)
            }

            if (root.has("folders")) {
                val fArray = root.getJSONArray("folders")
                for (i in 0 until fArray.length()) {
                    val obj = fArray.getJSONObject(i)
                    val folder = AppFolder(
                        name = obj.getString("name"),
                        icon = obj.optString("icon", "folder"),
                        colorHex = obj.optString("colorHex", "#3B82F6"),
                        pageIndex = obj.optInt("pageIndex", 0),
                        orderIndex = obj.optInt("orderIndex", 0)
                    )
                    folderDao.insertFolder(folder)
                }
            }

            if (root.has("apps")) {
                val aArray = root.getJSONArray("apps")
                for (i in 0 until aArray.length()) {
                    val obj = aArray.getJSONObject(i)
                    val folderId = obj.optLong("folderId", -1L)
                    val app = WebAppItem(
                        name = obj.getString("name"),
                        type = obj.getString("type"),
                        targetUrl = obj.getString("targetUrl"),
                        iconPreset = obj.optString("iconPreset", "#3B82F6"),
                        pageIndex = obj.optInt("pageIndex", 0),
                        orderIndex = obj.optInt("orderIndex", 0),
                        folderId = if (folderId > 0) folderId else null,
                        isLocked = obj.optBoolean("isLocked", false),
                        javascriptEnabled = obj.optBoolean("javascriptEnabled", true),
                        desktopMode = obj.optBoolean("desktopMode", false)
                    )
                    webAppDao.insertApp(app)
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
