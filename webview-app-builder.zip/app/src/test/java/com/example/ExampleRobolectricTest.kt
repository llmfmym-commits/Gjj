package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.AppRepository
import com.example.data.model.AppFolder
import com.example.data.model.AppSettings
import com.example.data.model.WebAppItem
import com.example.util.FileUtils
import com.example.util.ZipSecurityUtil
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var repository: AppRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = AppRepository(context, database)
    }

    @After
    fun tearDown() {
        database.close()
    }

    // 1. App Launch & Resource Test
    @Test
    fun test01_AppOpenAndStringResource() {
        val appName = context.getString(R.string.app_name)
        assertEquals("WebView App Builder", appName)
    }

    // 2. Add Web App to Database
    @Test
    fun test02_AddWebApp() = runBlocking {
        val app = WebAppItem(
            name = "Test Site",
            type = "WEB_URL",
            targetUrl = "https://example.com",
            pageIndex = 0,
            orderIndex = 0
        )
        val id = repository.insertApp(app)
        assertTrue(id > 0)

        val retrieved = repository.getAppById(id)
        assertNotNull(retrieved)
        assertEquals("Test Site", retrieved?.name)
        assertEquals("https://example.com", retrieved?.targetUrl)
    }

    // 3. Database Persistence & Query
    @Test
    fun test03_DatabasePersistence() = runBlocking {
        val app1 = WebAppItem(name = "App 1", type = "WEB_URL", targetUrl = "https://1.com")
        val app2 = WebAppItem(name = "App 2", type = "WEB_URL", targetUrl = "https://2.com")
        repository.insertApp(app1)
        repository.insertApp(app2)

        val apps = repository.allApps.first()
        assertEquals(2, apps.size)
    }

    // 4. Create Folder
    @Test
    fun test04_CreateFolder() = runBlocking {
        val folder = AppFolder(name = "Social", colorHex = "#3B82F6", pageIndex = 0)
        val folderId = repository.insertFolder(folder)
        assertTrue(folderId > 0)

        val folders = repository.allFolders.first()
        assertEquals(1, folders.size)
        assertEquals("Social", folders.first().name)
    }

    // 5. Delete Web App
    @Test
    fun test05_DeleteWebApp() = runBlocking {
        val app = WebAppItem(name = "To Delete", type = "WEB_URL", targetUrl = "https://del.com")
        val id = repository.insertApp(app)
        val inserted = repository.getAppById(id)!!

        repository.deleteApp(inserted)
        val retrieved = repository.getAppById(id)
        assertNull(retrieved)
    }

    // 6. Move Web App into Folder
    @Test
    fun test06_MoveAppToFolder() = runBlocking {
        val folderId = repository.insertFolder(AppFolder(name = "Work"))
        val appId = repository.insertApp(WebAppItem(name = "Slack", type = "WEB_URL", targetUrl = "https://slack.com"))

        repository.updateAppPosition(appId, 0, 0, folderId)
        val updated = repository.getAppById(appId)
        assertEquals(folderId, updated?.folderId)
    }

    // 7. Multi-page Positioning
    @Test
    fun test07_MultiPagePositioning() = runBlocking {
        val appId = repository.insertApp(WebAppItem(name = "Page 2 App", type = "WEB_URL", targetUrl = "https://p2.com"))
        repository.updateAppPosition(appId, 1, 3, null)

        val updated = repository.getAppById(appId)
        assertEquals(1, updated?.pageIndex)
        assertEquals(3, updated?.orderIndex)
    }

    // 8. Zip Slip Vulnerability Mitigation (Path Traversal Security)
    @Test
    fun test08_ZipSlipSecurityMitigation() {
        val targetDir = File(context.cacheDir, "test_zip_slip").apply { mkdirs() }

        // Craft malicious ZIP entry attempting path traversal out of destination
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            zos.putNextEntry(ZipEntry("../../evil.txt"))
            zos.write("malicious payload".toByteArray())
            zos.closeEntry()
        }

        val bais = ByteArrayInputStream(baos.toByteArray())
        var exceptionThrown = false
        try {
            ZipSecurityUtil.extractSafely(bais, targetDir)
        } catch (e: SecurityException) {
            exceptionThrown = true
        }
        assertTrue("Zip Slip vulnerability not blocked with SecurityException!", exceptionThrown)
        val evilFile = File(context.cacheDir, "evil.txt")
        assertFalse("Zip Slip vulnerability not mitigated!", evilFile.exists())
    }

    // 9. Valid ZIP Extraction
    @Test
    fun test09_ValidZipExtraction() {
        val targetDir = File(context.cacheDir, "test_valid_zip").apply { mkdirs() }

        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            zos.putNextEntry(ZipEntry("index.html"))
            zos.write("<h1>Hello Zip</h1>".toByteArray())
            zos.closeEntry()
        }

        val bais = ByteArrayInputStream(baos.toByteArray())
        val indexFile = ZipSecurityUtil.extractSafely(bais, targetDir)
        assertNotNull(indexFile)
        assertTrue(indexFile!!.exists())
        assertEquals("<h1>Hello Zip</h1>", indexFile.readText())
    }

    // 10. Wallpaper and Appearance Settings
    @Test
    fun test10_WallpaperSettings() {
        val settings = AppSettings(
            wallpaperType = "GRADIENT",
            wallpaperValue = "GRADIENT_OCEAN",
            columnCount = 5,
            themeMode = "DARK"
        )
        repository.updateSettings(settings)

        val loaded = repository.settingsFlow.value
        assertEquals("GRADIENT", loaded.wallpaperType)
        assertEquals("GRADIENT_OCEAN", loaded.wallpaperValue)
        assertEquals(5, loaded.columnCount)
        assertEquals("DARK", loaded.themeMode)
    }

    // 11. Master App Lock
    @Test
    fun test11_MasterAppLock() {
        val settings = AppSettings(
            appLockEnabled = true,
            masterPin = "1357"
        )
        repository.updateSettings(settings)

        val loaded = repository.settingsFlow.value
        assertTrue(loaded.appLockEnabled)
        assertEquals("1357", loaded.masterPin)
    }

    // 12. Individual App PIN Lock
    @Test
    fun test12_IndividualAppLock() = runBlocking {
        val app = WebAppItem(
            name = "Bank",
            type = "WEB_URL",
            targetUrl = "https://bank.com",
            isLocked = true,
            pinCode = "9988"
        )
        val id = repository.insertApp(app)
        val loaded = repository.getAppById(id)
        assertTrue(loaded?.isLocked == true)
        assertEquals("9988", loaded?.pinCode)
    }

    // 13. Hide and Unhide App
    @Test
    fun test13_HideAndUnhideApp() = runBlocking {
        val app = WebAppItem(
            name = "Secret App",
            type = "WEB_URL",
            targetUrl = "https://secret.com",
            isHidden = true
        )
        val id = repository.insertApp(app)
        val loaded = repository.getAppById(id)
        assertTrue(loaded?.isHidden == true)

        repository.updateApp(loaded!!.copy(isHidden = false))
        val unhidden = repository.getAppById(id)
        assertFalse(unhidden?.isHidden == true)
    }

    // 14. HTML Project Builder Generation
    @Test
    fun test14_HtmlProjectGeneration() {
        val path = FileUtils.saveHtmlProject(
            context = context,
            appId = "unit_test_app",
            htmlContent = "<p>My Test HTML</p>",
            cssContent = "p { color: red; }",
            jsContent = "console.log('test');"
        )
        val file = File(path)
        assertTrue(file.exists())
        val content = file.readText()
        assertTrue(content.contains("<p>My Test HTML</p>"))
        assertTrue(content.contains("color: red;"))
    }

    // 15. Backup Export JSON
    @Test
    fun test15_BackupExportJson() = runBlocking {
        val apps = listOf(WebAppItem(name = "ExportMe", type = "WEB_URL", targetUrl = "https://export.com"))
        val folders = listOf(AppFolder(name = "ExportFolder"))

        val json = repository.exportBackupJson(apps, folders)
        assertTrue(json.contains("ExportMe"))
        assertTrue(json.contains("ExportFolder"))
        assertTrue(json.contains("settings"))
    }

    // 16. Backup Restore JSON
    @Test
    fun test16_BackupRestoreJson() = runBlocking {
        val backupPayload = """
            {
              "settings": {
                "wallpaperType": "COLOR",
                "wallpaperValue": "#123456",
                "columnCount": 3
              },
              "folders": [
                { "name": "Restored Folder", "colorHex": "#3B82F6", "pageIndex": 0, "orderIndex": 0 }
              ],
              "apps": [
                { "name": "Restored App", "type": "WEB_URL", "targetUrl": "https://restored.com", "pageIndex": 0, "orderIndex": 0 }
              ]
            }
        """.trimIndent()

        val success = repository.restoreBackupJson(backupPayload)
        assertTrue(success)

        val restoredApps = repository.allApps.first()
        assertTrue(restoredApps.any { it.name == "Restored App" })

        val restoredFolders = repository.allFolders.first()
        assertTrue(restoredFolders.any { it.name == "Restored Folder" })

        assertEquals(3, repository.settingsFlow.value.columnCount)
    }

    // 17. WebView Incognito and Settings
    @Test
    fun test17_WebViewSettings() = runBlocking {
        val incognitoApp = WebAppItem(
            name = "Private Search",
            type = "WEB_URL",
            targetUrl = "https://duckduckgo.com",
            isIncognito = true,
            desktopMode = true,
            javascriptEnabled = false
        )
        val id = repository.insertApp(incognitoApp)
        val loaded = repository.getAppById(id)!!

        assertTrue(loaded.isIncognito)
        assertTrue(loaded.desktopMode)
        assertFalse(loaded.javascriptEnabled)
    }

    // 18. Persian Characters & Numbers Support
    @Test
    fun test18_PersianCharactersSupport() {
        val persianLetters = listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "چ", "گ")
        val persianDigits = listOf("۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹", "۰")

        assertEquals(13, persianLetters.size)
        assertEquals(10, persianDigits.size)
        assertTrue(persianLetters.contains("گ"))
        assertTrue(persianDigits.contains("۰"))
    }

    // 19. English and Shift Logic
    @Test
    fun test19_EnglishAndShiftLogic() {
        val lowercase = "webview"
        val uppercase = lowercase.uppercase()
        assertEquals("WEBVIEW", uppercase)
    }

    // 20. App Last Used Tracking
    @Test
    fun test20_AppLastUsedTracking() = runBlocking {
        val app = WebAppItem(name = "Tracked", type = "WEB_URL", targetUrl = "https://t.com")
        val id = repository.insertApp(app)

        assertEquals(0L, repository.getAppById(id)?.lastUsedAt)
        repository.updateLastUsed(id)

        val after = repository.getAppById(id)?.lastUsedAt ?: 0
        assertTrue(after > 0)
    }
}
